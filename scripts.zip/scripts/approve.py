from pathlib import Path, shutil, cv2

APP = Path("/Users/shahansahay/Desktop/PIPELINEFINAL/approved")
IMG_DST = Path("/Users/shahansahay/Desktop/PIPELINEFINAL/dataset/images")
LBL_DST = Path("/Users/shahansahay/Desktop/PIPELINEFINAL/dataset/labels")
IMG_DST.mkdir(parents=True, exist_ok=True)
LBL_DST.mkdir(parents=True, exist_ok=True)

for img in APP.glob("*.jpg"):
    lbl = img.with_suffix(".txt")
    pic = cv2.imread(str(img))
    cv2.imshow("Approve?  A=accept   R=reject  Any other=skip", pic)
    k = cv2.waitKey(0)
    if k in (ord("A"), ord("a")):
        shutil.move(str(img), IMG_DST / img.name)
        shutil.move(str(lbl), LBL_DST / lbl.name)
    elif k in (ord("R"), ord("r")):
        img.unlink(); lbl.unlink()
    cv2.destroyAllWindows()

