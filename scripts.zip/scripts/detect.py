from pathlib import Path
import cv2, argparse, uuid, os
from ultralytics import YOLO

QUEUE_DIR = Path("/Users/shahansahay/Desktop/PIPELINEFINAL/queue")

def save_queue_sample(img, boxes, cls, names):
    uid = uuid.uuid4().hex
    img_out = QUEUE_DIR / f"{uid}.jpg"
    lbl_out = QUEUE_DIR / f"{uid}.txt"
    cv2.imwrite(str(img_out), img)
    with open(lbl_out, "w") as f:
        for box in boxes:
            xc, yc, w, h = box
            f.write(f"{cls} {xc} {yc} {w} {h}\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="input")
    ap.add_argument("--model", default="/Users/shahansahay/Desktop/PIPELINEFINAL/best.pt")
    ap.add_argument("--thr", type=float, default=0.50)
    args = ap.parse_args()

    model = YOLO(args.model)
    src = Path(args.source)
    imgs = list(src.glob("*.*"))
    for p in imgs:
        res = model.predict(str(p), conf=0.01, save=False)[0]
        low_conf = [i for i, c in enumerate(res.boxes.conf) if c < args.thr]
        if not low_conf:
            continue
        annotated = res.plot()
        save_queue_sample(
            annotated,
            res.boxes.xywh[low_conf].tolist(),
            int(res.boxes.cls[low_conf][0]),
            model.names
        )
    print("Low‑confidence detections moved to queue")

if __name__ == "__main__":
    QUEUE_DIR.mkdir(exist_ok=True, parents=True)
    main()

