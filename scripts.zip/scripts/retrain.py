from pathlib import Path, subprocess, datetime

ROOT = Path("/Users/shahansahay/Desktop/PIPELINEFINAL")
BACK = ROOT / "train_backups"
BACK.mkdir(exist_ok=True)
stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

subprocess.run(
    [
        "yolo",
        "train",
        "model=yolov8m.pt",
        f"data={ROOT/'dataset'}",
        "epochs=100",
        "imgsz=640",
        f"project={BACK}",
        f"name=run_{stamp}",
    ],
    check=True,
)

