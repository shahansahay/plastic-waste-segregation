import os, json
from pathlib import Path
import google.generativeai as genai

QUEUE = Path("/Users/shahansahay/Desktop/PIPELINEFINAL/queue")
APPROVED = Path("/Users/shahansahay/Desktop/PIPELINEFINAL/approved")
LABEL_MAP = {"PET": 0, "HDPE": 1, "LDPE": 2, "PP": 3}

genai.configure(api_key=os.environ["GEMINI_API_KEY"])
model = genai.GenerativeModel("gemini-pro-vision")

def verify(img_bytes, guess):
    prompt = (
        "You are validating plastic‑type predictions. "
        f"The model guessed {guess}. Allowed labels: PET, HDPE, LDPE, PP. "
        "Reply ONLY the correct label or 'reject'."
    )
    resp = model.generate_content([prompt, img_bytes])
    return resp.text.strip().upper()

for img_path in QUEUE.glob("*.jpg"):
    lbl_path = img_path.with_suffix(".txt")
    guess_id = int(open(lbl_path).read().split()[0])
    guess = list(LABEL_MAP.keys())[list(LABEL_MAP.values()).index(guess_id)]
    with open(img_path, "rb") as f:
        decision = verify(f.read(), guess)
    if decision == "REJECT":
        img_path.unlink(); lbl_path.unlink(); continue
    new_id = LABEL_MAP[decision]
    APPROVED.mkdir(exist_ok=True)
    img_path.rename(APPROVED / img_path.name)
    lbl_path.rename(APPROVED / lbl_path.name)
    with open(APPROVED / lbl_path.name, "w") as f:
        f.write(f"{new_id} 0.5 0.5 1 1\n")
    print(f"{img_path.name} → {decision}")

